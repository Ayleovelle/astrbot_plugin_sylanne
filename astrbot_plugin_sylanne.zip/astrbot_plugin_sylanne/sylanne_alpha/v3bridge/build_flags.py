"""Generated build flags for the v3 shadow path. Do not edit by hand."""

V3_SHADOW_ENABLED: bool = True
BUILD_CHANNEL: str = "grey"
